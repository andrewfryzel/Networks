from Crypto import *
import SimpleHTTPServer
from Crypto.Hash import SHA
import argparse
import socket
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Cipher import PKCS1_OAEP
from base64 import b64decode, b64encode
from Crypto.Cipher import PKCS1_v1_5 as CipherPKCS
from Crypto import Random
from Crypto.Cipher import DES
import SocketServer
import json
import os
import sys

#docs.python.org/2/howto/argparse.html
print("Type '-h' for options. Type -v to enable detailed output\n")

parser = argparse.ArgumentParser(description = 'Begin Bob Server')
parser.add_argument('port', type =int, metavar='port', default = 2100)
parser.add_argument('-bobPrivate', type=str, metavar = 'bobPrivate', help = "For Testing a Private Bob Key")
parser.add_argument('-bobPublic', type=str, metavar = 'bobPublic', help = "For Testing a Public Bob Key")
parser.add_argument('-certPrivate', type=str, metavar='certPrivate', help = "For Testing a Private Certificate")
parser.add_argument('-verbose', '-v', action='store_true', help = "Display Detailed Messages ")

args = parser.parse_args()
verbose = args.verbose
port = args.port

#https://www.stackoverflow.com/questions/7783308/os-path-dirname-file-returns-empty
#https://www.stackoverflow.com/questions/37863476/why-would.one-use-both-os-path-abspath-and-os-path-realpath
##https://www.stackoverflow.com/questions/16771894/python-nameerror-global-name-file-is-not-defined
#tutorialspoint.com/python/os_getcwd.htm
#docs.python.org/2/library/os.path.html
dirname = os.path.dirname(__file__)
cwd = os.getcwd()
path = os.path.abspath(os.path.join(cwd, dirname))

if verbose:
    print("Verbose Enabled\n")
    print("Arguments:")
    print(args)
    print("\n")
else:
    verbose = False

#docs.python.org/3/library/http.server.html
#gist.github.com/nitaku/10d0662536f37a087e1b
class Simple_HTTP_Server(SimpleHTTPServer.SimpleHTTPRequestHandler):

#============================  Part 1 ============================
    def do_GET(self):

            print("Begin Transmission")
            #Get certificate Public Key from file
            inFile = open(os.path.join(path, "./CAPrivateKey.pem"), 'rb')
            caPrivateKey = RSA.importKey(inFile.read())
            cipher = PKCS1_v1_5.new(caPrivateKey)
            if verbose:
                print("\nRetrieved Certificat Private Key")

            #Get Bob Public Key
            inFile = open(os.path.join(path, "./BobPublicKey.pem"), 'rb')
            #Dont import, just read in. Dont have to do anything with it rn, just send in Json for Alice
            bobPub = inFile.read()
            #Encode. JSON requires encoding
            encodedBobPub = b64encode(bobPub)
            if verbose:
                print("\nBob Public Key (Encoded)")
                print(self.StringToHex(encodedBobPub))
            self.signDigest(verbose, bobPub,cipher, encodedBobPub)


#============================  Part 2 ============================

    #stackoverflow.com/questions/41429172/python-basehttprequesthandler-respond-with-json
    def do_POST(self):
        # For the taking apart of the big thing alice sends
        self.send_response(200)
        self.end_headers()

        #stackoverflow.com/questions/50880481/how-does-rfile-read-work
        #tackoverflow.com/questions/41429172/python-basehttprequesthandler-response-with-json
        #stackoverflow.com/questions/31371166/reading-json-from-implehttpserver-post-data
        length = int(self.headers['Content-Length'])
        body = self.rfile.read(length)
        content = json.loads(body)

        AliceMsgDigest = b64decode(content['encodedAlice'])
        encodedKey = b64decode(content['encodedKey'])
        if verbose:
            print("\nAlice Digest (Decoded):")
            print(self.StringToHex(AliceMsgDigest))
            print("\nEncrypted Symmetric Key (Decoded): ")
            print(self.StringToHex(encodedKey))

        self.decryptSessionKey(verbose,encodedKey,AliceMsgDigest)



#============================ Part 1 Helpers ============================
    def signDigest(self, verbose, bobPub, cipher, encodedBobPub):
                #Sign it
        hash = SHA.new(bobPub)
        bobDigest = cipher.sign(hash)
        #Encode. JSON required encoding
        encodedBobDigest = b64encode(bobDigest)
        if verbose:
            print("\nBob Digest (Encoded)")
            print(self.StringToHex(encodedBobDigest))
        self.createAndSendMessage(verbose, encodedBobPub,encodedBobDigest)

    def createAndSendMessage(self, verbose, encodedBobPub,encodedBobDigest):
        #Create JSON Object
        #learnpython.org/en/String_Formatting
        #stackoverflow.com/questions/997797/what-does-s-mean-in-a-python-format-string
        message = "{\"bobPub\": \"%s\", \"bobDigest\": \"%s\"}" % (encodedBobPub, encodedBobDigest)
        self.sendJSON(message)

        print("\nBob Digest Sent to Alice")

        if verbose:
            print("Bob Digest As A String: \n" )
            print(message)
            print("\nBob Digest As Hex")
            print(self.StringToHex(message))
        print("\n")

    #Send the message to Alice Via JSON
    def sendJSON(self,message):
        self.send_response(200, message = json.dumps(message))
        self.send_header("Content-type", "application/json")
        self.send_header("Content-Length", len(message))
        self.end_headers()
        self.wfile.write(message)


#============================  Part 2 Helpers============================
    def decryptSessionKey(self,verbose, encodedKey,AliceMsgDigest):
        #Decrypt Session key
        bobPrivateKey = RSA.importKey(open(os.path.join(path, "./BobPrivateKey.pem"), 'rb'))
        cipher = CipherPKCS.new(bobPrivateKey)

        sentinel = Random.new().read(len(encodedKey))
        message = json.loads(cipher.decrypt(encodedKey, sentinel))

        encodedKey = message["key"]
        encodedIV = message["iv"]

        key = b64decode(encodedKey)
        iv =b64decode(encodedIV)
        if verbose:
            print("\nSymmetric Key (Encoded):")
            print(self.StringToHex(key))
            print("\nSymmetric Key IV (Encoded): ")
            print(self.StringToHex(iv))
        self.decryptAliceBlock(verbose, iv, key, AliceMsgDigest)


    def decryptAliceBlock(self, verbose, iv, key, AliceMsgDigest):

        cipher = DES.new(key, DES.MODE_OFB, iv)
        decDigest = cipher.decrypt(AliceMsgDigest)

        decryptAliceDigest = json.loads(decDigest)

        #Alices MESSAGE
        originalMessage = decryptAliceDigest["originalMessage"]
        originalMessage = b64decode(originalMessage)

        aliceDigest = decryptAliceDigest["aliceDigest"]
        aliceDigest = b64decode(aliceDigest)

        if verbose:
            print("\nOriginal Message(Decoded):")
            print(self.StringToHex(originalMessage))
            print("\nAlice Digest (Decoded): ")
            print(self.StringToHex(aliceDigest))

        self.verifiyAlice(verbose, originalMessage, aliceDigest )


    def verifiyAlice(self, verbose, originalMessage, aliceDigest ):
        #VERIFY
        AlicePublicKey = RSA.importKey(open(os.path.join(path, "./AlicePrivateKey.pem"), 'rb'))

        cipher = PKCS1_v1_5.new(AlicePublicKey)
        hash = SHA.new(originalMessage)
        if cipher.verify(hash, aliceDigest):
            print("\nALICE SIGNATURE VERIFIED\n")
            print("Unencrypted Message: %s" % originalMessage)
            print("\nTRANSMISSION COMPLETE")

        else:
            print("\nALICE SIGNATURE NOT VERIFIED\n")
            print("\nTRANSMISSION AND DECRYPTION FAILED")



    #stackoverflow.com/questions/12214801/print-a-string-as-hex-bytes
    def StringToHex(self, s):
        return ':'.join("{:02x}".format(ord(c)) for c in s)


    #stackoverflow.com/questions/14984401/simplehttpserver-and-socketserver
    #docs.python.org/2/library/basehttpserver.html
    #docs.python.org/2/library/basehttpserver.html#BaseHTTPServer.HTTPServer
def main():
    Handler = Simple_HTTP_Server

    try:
        #docs.python.org/2/library/socketserver.html
        httpServerInit = SocketServer.TCPServer(('localhost',port),Handler)

        print("Listening...\n")
        #Keep alive during transmission
        while True:
            httpServerInit.handle_request()

    except KeyboardInterrupt:
        print("\nProgram Forcefully Ended")



if __name__ == '__main__':
    main()





#FROM WHEN I WAS USING SOCKET AND TCP STUFF, IGNORE
"""
    inFile = open(args.bobPrivate,'rb')
    bobPrivateKey = RSA.importKey(inFile.read())
    #privBob = bobPrivateKey.exportKey(bobPrivateKey)
    print("BOBPRIVATE")
    print(bobPrivateKey)

    inFile = open(args.bobPublic,'rb')
    #bobPublicKey = RSA.importKey(inFile.read())
    bobPublicKey= inFile.read()

    print(bobPublicKey)
    #print(bobPublicKey.encode("utf-8"))

    inFile = open(args.certPrivate,'rb')
    certPrivateKey = RSA.importKey(inFile.read())
    print(certPrivateKey)

    #https://stackabuse.com/file-handling-in-python/
    #with open("BobPrivateKey", "rb") as inFile:
    #    bobPrivateKey =


    host = '127.0.0.1'
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((host, args.port))
    sock.listen(10)

    while True:
        print("Listening")

        (alicecon, aliceAddr) = sock.accept()
        print(alicecon)
        print("and addr is ")
        print(aliceAddr)


        #Send back message digest

        #return encoded digest
        bobDigest = str(createDigest(certPrivateKey, bobPublicKey))
        bobDigest = combineMessage(bobPublicKey, bobDigest)
        alicecon.send(bobDigest)


        rec = alicecon.recv(1024)
        rec = alicecon.recv(1024)

        print("RECEIVED THIS")
        print(rec)

        recLines = rec.splitlines()
        print("RECEIVED LINE")
        print(recLines[0])
        print("RECEIVED LINE")
        print(recLines[1])
        print("RECEIVED LINE")


        len1= len(recLines[0])
        len2 = len(recLines[1])
        len3 = len(recLines[2])

        start = len1+len2+len3+6
        print(len(recLines))
        stuff = rec[start:]
        print(stuff)

        l1 = int(recLines[0])
        l2 = int(recLines[1])
        l3 = int(recLines[2])

        print("l2", l2)
        start = 0
        encrypted=stuff[0:l1]
        print("encrypted")
        print(encrypted)

        end = l2+l1
        edes=stuff[l1:]
        print("encrypteddes")
        print(edes)

        #iv=stuff[end:l3+end]
        #print("iv")
        #print(iv)


        #Decrypt the keyIV
        cipher2 = Cipher_PKCS1_v1_5.new(bobPrivateKey)
        sentinel = Random.new().read(len(edes))
        symKey = cipher2.decrypt(edes, sentinel)
        print(symKey)

        #get key
        keyIV = symKey[-l3:]
        print(keyIV)

        #get Iv


        #print(encrypted)

        encrypted = recLines[0]
        desKey = recLines[1]
        print("\r\n\r\n")
        print("length of deskey")
        print(len(desKey))
        print(desKey)
        iv = recLines[2]
        desKey2 = b64decode(desKey)
        print("\r\n\r\n")
        print("length of deskey")
        print(len(desKey2))
        print(desKey2)


        cipher = PKCS1_OAEP.new(bobPrivateKey)
        key = cipher.decrypt(b64decode(desKey))

        #print(b64decode(message))

        #decrypt left side using des3 from last section
        print("KEY")
        print(key)

        cipher = DES3.new(key, DES3.MODE_OFB, iv)
        decryptedDes = cipher.decrypt(encrypted)


        #verify signature and message

        # get Des3 using bob Key
        #size = SHA.digest_size
        #sentinel = Random.new().read(len(desKey)+size)
        bobkey = cls.import_key(bobPrivateKey)
        cipher = PKCS1_OAEP.new(bobkey)
        length = len(bobPrivateKey)
        res = []
        for i in range(0, len(desKey), length):
            decrypted = cipher.decrypt(desKey[i:i+length])
            res.append(decrypted)
        decryptedKey = "".join(res)
        print(decryptedKey)







        lines = rec.splitlines()
        print("ALL LINES")
        print(lines)
        aMessage = lines[0]
        aDigest = lines[1]
        print("\r\n" + "Alice Message")
        print(aMessage)
        print("\r\nAlice digest")
        print(aDigest)

        print(b64decode(aMessage))

        print(b64decode(aDigest))

        #THIS WORKS TO GET THE MESSAGE
    """
"""
def createDigest(certPrivateKey, bobPublicKey):
    #pubkey + hashofpubkey signed
    hash = SHA.new(bobPublicKey)

    cipher = PKCS1_v1_5.new(certPrivateKey)
    signature = cipher.sign(hash)

    return signature

def combineMessage(bobPublicKey, bobDigest):
    b = b64encode(bobPublicKey)

    blen = len(b)
    bdlen=len(bobDigest)
    message = str(blen) + "\r\n" + b + "\r\n" +  str(bdlen) + "\r\n" +bobDigest

    return message

"""
