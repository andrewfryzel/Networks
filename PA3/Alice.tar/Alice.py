from Crypto import *
from Crypto.PublicKey import RSA
import argparse
import requests
import socket
from Crypto.Signature import PKCS1_v1_5
from Crypto.Cipher import PKCS1_v1_5 as CipherPKCS
from base64 import b64decode, b64encode
from Crypto.Hash import SHA
from Crypto.Cipher import DES
from Crypto import Random
import os
from Crypto.Cipher import PKCS1_OAEP

#https://www.stackoverflow.com/questions/7783308/os-path-dirname-file-returns-empty
#https://www.stackoverflow.com/questions/37863476/why-would.one-use-both-os-path-abspath-and-os-path-realpath
##https://www.stackoverflow.com/questions/16771894/python-nameerror-global-name-file-is-not-defined
#tutorialspoint.com/python/os_getcwd.htm
#docs.python.org/2/library/os.path.html
dirname = os.path.dirname(__file__)
cwd = os.getcwd()
path = os.path.abspath(os.path.join(cwd, dirname))

#stackoverflow.com/questions/12214801/print-a-string-as-hex-bytes
def StringToHex(s):
    return ':'.join("{:02x}".format(ord(c)) for c in s)

verbose = False

def main():
    #global verbose
    #parse arguments
    #docs.python.org/2/howto/argparse.html
    print("Type '-h' for options. Type -v to enable detailed output\n")
    parser = argparse.ArgumentParser(description = 'Begin Client Requests')
    parser.add_argument('host', type =str, metavar='host', default='localhost', help = "IP to connect to")
    parser.add_argument('port', type =int, metavar='port', default = 2100, help = "Port to connect to")
    parser.add_argument('-certPrivate', type=str, metavar='certPrivate', help = "For Testing a Private Certificate")
    parser.add_argument('-certPublic', type=str, metavar='certPublic', help = "For Testing a Public Certificiate")
    parser.add_argument('message', type=str, metavar='message', help = "Message to be encrypted and sent")
    parser.add_argument('-alicePrivate', type=str, metavar = 'alicePrivate', help = "For Testing a Private Alice Key")
    parser.add_argument('-bobPublic', type=str, metavar = 'bobPublic', help = "For Testing a Public Bob Key")
    parser.add_argument('-alicePublic', type=str, metavar = 'alicePublic', help = "For Testing a Public Alice Key")
    parser.add_argument('-v',  action='store_true', help = "Display Detailed Messages ")

    args = parser.parse_args()
    host = args.host
    port = args.port
    verbose = False

    if(args.v):
        verbose = True
    else:
        verbose = False

    if verbose:
        print("Verbose Enabled")



#============================ Part 1 ============================
    #Incoming JSON Message
    message = requests.get('http://%s:%s/' % (host, port))
    if verbose:
        print("\nBob Digest Received")

    rec = message.json()

    encryptedBobPub = rec["bobPub"]
    encryptedBobDigest = rec["bobDigest"]
    bobPub = b64decode(encryptedBobPub)
    bobDigest = b64decode(encryptedBobDigest)
    decodeJSON(encryptedBobPub,encryptedBobDigest, bobPub, bobDigest, verbose, args)


#============================ Part 2 ============================
    originalMessage = args.message
    if verbose:
        print("Original Message As A String: %s" %originalMessage)
        print("Original Message As Hex: %s" % StringToHex(originalMessage))
        print("\n")

    signWithAlice(args, verbose, originalMessage, bobPub)


#============================ Part 1 Helpers ============================
def decodeJSON(encryptedBobPub,encryptedBobDigest, bobPub, bobDigest, verbose, args):
    #Have to decode the JSON parts
    if verbose:
        print("\nBob Digest (Decoded):")
        print(StringToHex(bobPub))
        print("\nBob Public Key (Decoded): ")
        print(StringToHex(bobPub))

    verify(bobPub, bobDigest, verbose, args)

def verify(bobPub, bobDigest, verbose, args):
    # VERIFY
    #Get Certificate Public Key
    inFile = open(os.path.join(path, "./CAPublicKey.pem"), 'rb')
    certPublicKey = RSA.importKey(inFile.read())
    if verbose:
        print("\nCertificate Public Key Retrieved\n")

    #Verify using PKCS_v1_5
    cipher = PKCS1_v1_5.new(certPublicKey)
    hash = SHA.new(bobPub)
    if cipher.verify(hash, bobDigest):
        print("BOB SIGNATURE VERIFIED\n")
    else:
        print("BOB SIGNATURE NOT VERIFIED\n")


#============================ Part 2 Helpers ============================
def signWithAlice(args,verbose, originalMessage, bobPub):
    #sign with Alice Private Key
    inFile = open(os.path.join(path, "./AlicePrivateKey.pem"), 'rb')
    alicePrivateKey = RSA.importKey(inFile.read())
    cipher = PKCS1_v1_5.new(alicePrivateKey)

    if verbose:
        print("Alice Private Key Retrieved")
        print(alicePrivateKey)

    hash = SHA.new(originalMessage)
    aliceDigest = cipher.sign(hash)
    if verbose:
        print("\nAlice Digest Encrypted")

    combineDigestAndMessage(args, verbose, aliceDigest, originalMessage, bobPub)


def combineDigestAndMessage(args, verbose, aliceDigest, originalMessage, bobPub):
    #concatonate encoded digest with message
    encodedAliceDigest = b64encode(aliceDigest)
    encodedOriginalMessage = b64encode(originalMessage)
    if verbose:
        print("\nAlice Digest (Encoded): ")
        print(StringToHex(encodedAliceDigest))
        print("\nAlice Original Message (Encoded): ")
        print(StringToHex(encodedOriginalMessage))

    #learnpython.org/en/String_Formatting
    #stackoverflow.com/questions/997797/what-does-s-mean-in-a-python-format-string
    aliceDigestAndMsg = "{\"originalMessage\": \"%s\", \"aliceDigest\": \"%s\"}" % (encodedOriginalMessage, encodedAliceDigest)

    encryptWithDES3(args, verbose, aliceDigestAndMsg, bobPub)


def encryptWithDES3(args, verbose, aliceDigestAndMsg, bobPub):
    #encrypt with des3
    key = b'-8B key-'
    iv = Random.new().read(DES.block_size)
    cipher = DES.new(key, DES.MODE_OFB, iv)

    if len(aliceDigestAndMsg) % 8 !=0:
        add = 8 - len(aliceDigestAndMsg) % 8
        while add > 0:
            aliceDigestAndMsg +=" "
            add -=1

    Ks_AliceDigestAndMsg = cipher.encrypt(aliceDigestAndMsg)
    encodedIV = b64encode(iv)
    encodedKey = b64encode(key)

    if verbose:
        print("\nDES IV (Encoded): ")
        print(StringToHex(encodedIV))
        print("\nDES Key (Encoded): ")
        print(StringToHex(encodedKey))
        print("\nSession Key (IV + KEY) (Encoded):")
        print(StringToHex(encodedIV + encodedKey))

    encryptKSWithBob(args, verbose, bobPub, Ks_AliceDigestAndMsg, encodedKey, encodedIV)

def encryptKSWithBob(args, verbose, bobPub, Ks_AliceDigestAndMsg, encodedKey, encodedIV):
    #Encrypt Ks key with bobPublic
    bobPublicKey = RSA.importKey(bobPub)
    cipher = CipherPKCS.new(bobPublicKey)

    kB_kS = cipher.encrypt("{\"key\": \"%s\", \"iv\": \"%s\"}" % (encodedKey, encodedIV))
    encodedAlicedDigestAndMsg = b64encode(Ks_AliceDigestAndMsg)
    encodedkB_kS = b64encode(kB_kS)

    if verbose:
        print("\nAlice Digest And Message (Encoded): ")
        print(StringToHex(encodedkB_kS))
        print("\nBob Public Key Encrypted With Symm Key (Encoded): ")
        print(StringToHex(encodedAlicedDigestAndMsg))

    sendMessageToBob(args,verbose,encodedAlicedDigestAndMsg, encodedkB_kS )

def sendMessageToBob(args,verbose,encodedAlicedDigestAndMsg, encodedkB_kS ):
    messageToBob = "{\"encodedAlice\": \"%s\", \"encodedKey\": \"%s\"}" % (encodedAlicedDigestAndMsg, encodedkB_kS)

    message = requests.post('http://%s:%s/' % (args.host, args.port), data= messageToBob, headers={'Connection':'close'})

    if verbose:
        print(StringToHex(message))
        print("\nJSON Message As Hex: ")
        print(StringToHex(messageToBob))

    print("\nEncrypted Message Sent to Bob")
    print("\nALICE DONE")


if __name__ == '__main__':
    main()





#FROM WHEN I WAS USING SOCKET AND TCP STUFF. IGNORE

"""
    #TODO error check the incoming ArgumentParser
    inFile = open(args.certPublic,'rb')
    certPublicKey = RSA.importKey(inFile.read())
    print(certPublicKey)

    inFile = open(args.alicePrivate,'rb')
    alicePrivateKey = RSA.importKey(inFile.read())
    print(alicePrivateKey)

    inFile = open(args.bobPublic,'rb')
    bobPublicKey = RSA.importKey(inFile.read())
    print(bobPublicKey)

    inFile = open(args.alicePublic,'rb')
    alicePublicKey = RSA.importKey(inFile.read())
    print(alicePublicKey)


    print("the message to bob is " + args.message)

    #connect to Bob
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((args.host, args.port))
    print("1")

    sock.send(args.message)
    print("2")

    rec = sock.recv(1024)
    print(rec)

    lines = rec.splitlines()
    #print(lines[0])

    end = int(lines[0])
    BPub = lines[1]

    BDigEnd = lines[3]
    print("\r\n")
    print(BPub)
    print("\r\nBD")
    print(BDigEnd)

    #Verify the signature

    BPub = b64decode(BPub)
    #BDig = b64decode(BDigEnd)
    print("\r\nBPUBLIC")
    print(BPub)
    #print("\r\n")
    #print(BDig)

    hash = SHA.new(BPub)
    cipher = PKCS1_v1_5.new(certPublicKey)

    if cipher.verify(hash, BDigEnd):
        print("verified")

    print("\r\n")


#VERFICATION DONE STEP 1 COMPLETE


    #Create left side
    aliceDigest1 = str(createDigest(args.message, alicePrivateKey))
    print("BEFORE COMBINE")
    print(aliceDigest1)
    print(args.message)

    aliceDigest = str(combineMessage(args.message, aliceDigest1))

    #Helper decrypt to orgiinal message and verify sign
    #decryptDigest(aliceDigest, alicePublicKey, aliceDigest1)
    #sock.send(str(aliceDigest))
    #create left side finished
#TODO
    #Generate DES3 and encrypt alicedigest with DES3
    key = Random.new().read(16)
    iv = Random.new().read(DES3.block_size)
    descipher = DES3.new(key,DES3.MODE_OFB, iv)
    if len(aliceDigest) % 8 !=0:
        add = 8 - len(aliceDigest) % 8
        while add > 0:
            aliceDigest +=" "
            add -=1
    encrypted = descipher.encrypt(aliceDigest)
    print("symkey before", encrypted)

    #decryptEncrypted(encrypted, descipher)



    #Encrypt DES3 key with bob PublicKey

    hashKey = str(cipher)
    print("desKey")
    print(hashKey)
    hash = SHA.new(hashKey)
    BobPublicUse = RSA.importKey(BPub)
    cipher = CipherPKCS.new(BobPublicUse)
    encryptedDes = cipher.encrypt(str(hash))

    #wtih pkcs PKCS1
    keyIV = key + iv
    print(key)
    hash = SHA.new(keyIV)
    BobPublicUse = RSA.importKey(BPub)
    cipher = CipherPKCS.new(BobPublicUse)
    encryptedDes = cipher.encrypt(hash.digest())
    print(encryptedDes)
    print("iv", len(iv))

    print("KEY")
    print(len(str(descipher)))
    print("\r\n")
    print(descipher)
    len1= len(encrypted)
    len2 = len(encryptedDes)
    len3 = len(str(iv))
    print(len(str(len1)))
    #combind everything and send
    toSend = str(len1) + "\r\n" + str(len2) +"\r\n" + str(len3) + "\r\n" +encrypted + "" + encryptedDes
    print("\r\n\r\n")
    #print(len(encryptedDes))
    #print(encryptedDes)
    sock.send(str(toSend))
    print("IM SENDING THIS")
    print(toSend)

    print("\r\n\r\nEncrypted")
    print(encrypted)
    print("\r\n\r\nEncrypteddes")
    print(encryptedDes)
    print("\r\n\r\n")
    print(iv)



def createDigest(message, alicePrivateKey):
    #pubkey + hashofpubkey signed
    hash = SHA.new(message)

    cipher = PKCS1_v1_5.new(alicePrivateKey)
    signature = cipher.sign(hash)
    print("SIG")
    print(signature)

    return signature

def combineMessage(message, aliceDigest):

    message = message + "\r\n" + aliceDigest
    print("THIS IS WHAT YOUR WANT")
    print(aliceDigest)
    print("\r\nMESSAGE")
    print(message)
    print("\r\nMESSAGE")
    print(len(message.splitlines()))

    return message

def decryptDigest(aliceDigest, alicePublicKey, aliceDigest1):

    lines = aliceDigest.splitlines()
    message = lines[0]
    messageLen = len(message)
    print("the lines")

    AliceDig = aliceDigest[messageLen+2:]

    print("\r\n")
    print("\r\n")
    print("Alice VERIFY")
    print(AliceDig)

    hash = SHA.new(message)
    cipher = PKCS1_v1_5.new(alicePublicKey)

    print("DIG BEFORE VER")
    print(AliceDig)

    if cipher.verify(hash, AliceDig):
        print("verified ALICE DIGEST")
        print(message)

#def decryptEncrypted(encrypted):

"""
